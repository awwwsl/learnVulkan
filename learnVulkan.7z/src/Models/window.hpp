#define GLFW_INCLUDE_VULKAN

#include "../Utils/VkResultThrowable.hpp"
#include "graphic.hpp"

#include <vulkan/vulkan.h>
#include <vulkan/vulkan_core.h>

#include <GLFW/glfw3.h>

#include <chrono>
#include <functional>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <string>
#include <thread>
#include <vector>

namespace learnVulkan::models {

class window {
  struct LogicUpdateCallbackInfo {
    std::function<void(int framePassed, double timePassed)> callback;
    std::chrono::duration<double> interval;
    double lastTime;
    int framePassed;
  };
  static inline std::vector<LogicUpdateCallbackInfo> logicUpdateCallbacks;

public:
  window() {}

  const constexpr static VkExtent2D defaultSize = {1920, 1080};

  bool initialize();
  void run();

  std::string windowTitle = "Untitled";
};

} // namespace learnVulkan::models
