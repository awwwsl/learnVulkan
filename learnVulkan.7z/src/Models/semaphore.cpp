#include "../Utils/Macros.cpp"
#include <vulkan/vulkan.h>

class semaphore {
  VkSemaphore handle = VK_NULL_HANDLE;

public:
  // semaphore() = default;
  semaphore(VkSemaphoreCreateInfo &createInfo) { Create(createInfo); }
  // 默认构造器创建未置位的信号量
  semaphore(/*VkSemaphoreCreateFlags flags*/) { Create(); }
  semaphore(semaphore &&other) noexcept { MoveHandle; }
  ~semaphore() { DestroyHandleBy(vkDestroySemaphore); }
  // Getter
  DefineHandleTypeOperator;
  DefineAddressFunction;
  // Non-const Function
  VkResultThrowable Create(VkSemaphoreCreateInfo &createInfo) {
    createInfo.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO;
    VkResult result = vkCreateSemaphore(graphicsBase::Singleton().Device(),
                                        &createInfo, nullptr, &handle);
    if (result)
      printf("[ semaphore ] ERROR: Failed to create a "
             "semaphore!\nError code: %d\n",
             int32_t(result));
    return result;
  }
  VkResultThrowable Create(/*VkSemaphoreCreateFlags flags*/) {
    VkSemaphoreCreateInfo createInfo = {};
    return Create(createInfo);
  }
};
