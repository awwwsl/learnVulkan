#pragma once

#define GLFW_INCLUDE_VULKAN

#include "../Utils/VkResultThrowable.hpp"

#include <vector>
#include <vulkan/vulkan.h>

class graphicsBase {
  graphicsBase();
  graphicsBase(graphicsBase &&) = delete;
  graphicsBase operator&(const graphicsBase &) = delete;
  ~graphicsBase();

  // Non const函数
  VkResultThrowable GetQueueFamilyIndices(VkPhysicalDevice physicalDevice,
                                          bool enableGraphicsQueue,
                                          bool enableComputeQueue,
                                          uint32_t (&queueFamilyIndices)[3]);

  VkResultThrowable CreateDebugMessenger();

public:
  // Getter
  uint32_t ApiVersion() const;
  VkInstance Instance() const;
  VkPhysicalDevice PhysicalDevice() const;
  const VkPhysicalDeviceProperties &PhysicalDeviceProperties() const;
  const VkPhysicalDeviceMemoryProperties &
  PhysicalDeviceMemoryProperties() const;
  VkPhysicalDevice AvailablePhysicalDevice(uint32_t index) const;
  uint32_t AvailablePhysicalDeviceCount() const;

  VkDevice Device() const;
  uint32_t QueueFamilyIndex_Graphics() const;
  uint32_t QueueFamilyIndex_Presentation() const;
  uint32_t QueueFamilyIndex_Compute() const;
  VkQueue Queue_Graphics() const;
  VkQueue Queue_Presentation() const;
  VkQueue Queue_Compute() const;

  VkSurfaceKHR Surface() const;
  const VkFormat &AvailableSurfaceFormat(uint32_t index) const;
  const VkColorSpaceKHR &AvailableSurfaceColorSpace(uint32_t index) const;
  uint32_t AvailableSurfaceFormatCount() const;

  VkSwapchainKHR Swapchain() const;
  VkImage SwapchainImage(uint32_t index) const;
  VkImageView SwapchainImageView(uint32_t index) const;
  uint32_t SwapchainImageCount() const;
  const VkSwapchainCreateInfoKHR &SwapchainCreateInfo() const;

  const std::vector<const char *> &InstanceLayers() const;
  const std::vector<const char *> &InstanceExtensions() const;
  const std::vector<const char *> &DeviceExtensions() const;

  // Const函数
  VkResultThrowable CheckInstanceLayers(const char **layersToCheck,
                                        int length) const;
  VkResultThrowable
  CheckInstanceExtensions(const char **extensionsToCheck, int length,
                          const char *layerName = nullptr) const;
  VkResultThrowable
  CheckDeviceExtensions(const char **extensionsToCheck, int length,
                        const char *layerName = nullptr) const;
  // Non-const函数
  void AddInstanceLayer(const char *layerName);
  void AddInstanceExtension(const char *extensionName);
  void AddDeviceExtension(const char *extensionName);

  VkResultThrowable UseLatestApiVersion();

  VkResultThrowable CreateInstance(VkInstanceCreateFlags flags = 0);
  void Surface(VkSurfaceKHR surface);
  VkResultThrowable GetPhysicalDevices();
  VkResultThrowable DeterminePhysicalDevice(uint32_t deviceIndex,
                                            bool enableGraphicsQueue,
                                            bool enableComputeQueue);
  VkResultThrowable CreateDevice(VkDeviceCreateFlags flags = 0);
  VkResultThrowable GetSurfaceFormats();
  VkResultThrowable SetSurfaceFormat(VkSurfaceFormatKHR surfaceFormat);
  VkResultThrowable CreateSwapchain_Internal();
  VkResultThrowable CreateSwapchain(bool limitFrameRate = true,
                                    VkSwapchainCreateFlagsKHR flags = 0);

  VkResultThrowable RecreateSwapchain();
  void InstanceLayers(const std::vector<const char *> &layerNames);
  void InstanceExtensions(const std::vector<const char *> &extensionNames);
  void DeviceExtensions(const std::vector<const char *> &extensionNames);

  void AddCreateSwapchainCallback(void (*callback)());

  void AddDestroySwapchainCallback(void (*callback)());

  void AddCreateDeviceCallback(void (*callback)());

  void AddDestroyDeviceCallback(void (*callback)());

  // 该函数用于等待逻辑设备空闲
  VkResultThrowable WaitIdle() const;
  // 该函数用于重建逻辑设备
  VkResultThrowable RecreateDevice(VkDeviceCreateFlags flags = 0);
  void Terminate();
  static graphicsBase &Singleton();
};
