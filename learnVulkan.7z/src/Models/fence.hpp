#pragma once

#define GLFW_INCLUDE_VULKAN

#include "../Utils/Macros.cpp"
#include "../Utils/VkResultThrowable.hpp"
#include <vulkan/vulkan.h>

class fence {
  VkFence handle = VK_NULL_HANDLE;

public:
  // fence() = default;
  fence(VkFenceCreateInfo &createInfo);
  fence(VkFenceCreateFlags flags = 0);
  fence(fence &&other) noexcept;
  ~fence();
  // Getter
  DefineHandleTypeOperatorHeader;
  DefineAddressFunctionHeader;
  // Const Function
  VkResultThrowable Wait() const;
  VkResultThrowable Reset() const;
  // 因为“等待后立刻重置”的情形经常出现，定义此函数
  VkResultThrowable WaitAndReset() const;
  VkResultThrowable Status() const;
  // Non-const Function
  VkResultThrowable Create(VkFenceCreateInfo &createInfo);
  VkResultThrowable Create(VkFenceCreateFlags flags = 0);
};
