#include "../Utils/Macros.cpp"
#include <vulkan/vulkan.h>

class semaphore {
  VkSemaphore handle = VK_NULL_HANDLE;

public:
  // semaphore() = default;
  semaphore(VkSemaphoreCreateInfo &createInfo);
  // 默认构造器创建未置位的信号量
  semaphore(/*VkSemaphoreCreateFlags flags*/);
  semaphore(semaphore &&other) noexcept;
  ~semaphore();
  // Getter
  DefineHandleTypeOperatorHeader;
  DefineAddressFunctionHeader;
  // Non-const Function
  VkResultThrowable Create(VkSemaphoreCreateInfo &createInfo);
  VkResultThrowable Create(/*VkSemaphoreCreateFlags flags*/);
};
